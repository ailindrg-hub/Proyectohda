import { useState } from 'react';
import { StyleSheet, Text, TextInput, View, Pressable, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import RefugioScreenShell from '@/components/RefugioScreenShell';

export default function RegisterScreen() {
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [contacto, setContacto] = useState('');
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <RefugioScreenShell>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.container}>
            {/* Encabezado con Icono */}
            <View style={styles.header}>
              <View style={styles.iconCircle}>
                <Ionicons name="person-add" size={72} color="#1F6829" />
              </View>
              <Text style={styles.title}>Registro</Text>
            </View>

            {/* Formulario */}
            <View style={styles.form}>
              <Text style={styles.label}>Nombre</Text>
              <TextInput
                value={nombre}
                onChangeText={setNombre}
                placeholder="Tu nombre"
                placeholderTextColor="#8DAF8B"
                style={styles.input}
              />

              <Text style={styles.label}>Apellido</Text>
              <TextInput
                value={apellido}
                onChangeText={setApellido}
                placeholder="Tu apellido"
                placeholderTextColor="#8DAF8B"
                style={styles.input}
              />

              <Text style={styles.label}>Número o Correo</Text>
              <TextInput
                value={contacto}
                onChangeText={setContacto}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholder="correo@ejemplo.com o número"
                placeholderTextColor="#8DAF8B"
                style={styles.input}
              />
            </View>

            {/* Botones de Acción */}
            <View style={styles.actionsRow}>
              <Pressable 
                style={[styles.button, styles.leftButton]}
                onPress={() => router.back()}
              >
                <Text style={[styles.buttonText, styles.leftButtonText]}>Volver</Text>
              </Pressable>
              <Pressable 
                style={[styles.button, styles.rightButton]}
                onPress={() => {
                  const c = contacto.trim();
                  if (!c) {
                    alert('Ingresa tu correo o número de contacto');
                    return;
                  }
                  router.push({ pathname: '/create-password', params: { contacto: c } });
                }}
              >
                <Text style={[styles.buttonText, styles.rightButtonText]}>Siguiente</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      </RefugioScreenShell>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFEF5', // Fondo con toque amarillento
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingVertical: 40,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  iconCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#FFF9C4', // Amarillo suave
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#FBC02D', // Borde amarillo
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1F6829',
  },
  form: {
    gap: 18,
  },
  label: {
    fontSize: 16,
    fontWeight: '700',
    color: '#3E5D39',
    marginBottom: 8,
  },
  input: {
    height: 54,
    paddingHorizontal: 18,
    borderWidth: 1,
    borderColor: '#D8EBD2',
    borderRadius: 16,
    backgroundColor: '#F8FFF7',
    color: '#233627',
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 36,
    gap: 12,
  },
  button: {
    flex: 1,
    height: 54,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  leftButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#6BB55A',
  },
  rightButton: {
    backgroundColor: '#57A145',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '700',
  },
  leftButtonText: {
    color: '#57A145',
  },
  rightButtonText: {
    color: '#FFFFFF',
  },
});
